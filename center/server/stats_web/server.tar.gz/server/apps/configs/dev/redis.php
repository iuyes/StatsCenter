<?php
$redis['master'] = array(
    'host' => "localhost",
    'port' => 6379,
);
return $redis;